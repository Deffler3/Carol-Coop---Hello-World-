﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Hello.Models
{
    public class Detail
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}