﻿using Hello.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Hello.Controllers
{
    public class DetailsController : ApiController
    {
        Detail[] details = new Detail[]
        {
            new Detail { Id = 1, Name = "Hello World"}
        };

        public IEnumerable<Detail> GetAllDetails()
        {
            return details;
        }
    }
}